# SARGAM-2022
Everything was basic only the jpgs and links to SM are added
